# Copyright (c) Meta Platforms, Inc. and affiliates.
# SPDX-License-Identifier: GPL-3.0-or-later

"""
drgn internals

This package contains modules internal to drgn. You should not use them.
"""
